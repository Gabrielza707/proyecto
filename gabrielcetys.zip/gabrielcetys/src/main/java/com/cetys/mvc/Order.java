package com.cetys.mvc;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "order_table")
public class Order {
    @Id
            @GeneratedValue(strategy = GenerationType.AUTO)
    Integer id;
    String name;
    // Una orden tiene muchos productos
    @OneToMany(mappedBy = "order")

    List<Product> products;

    public Order() {
        products = new ArrayList<>();
    }

    public Order(String name) {
        this.name = name;
        products = new ArrayList<>();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
}
