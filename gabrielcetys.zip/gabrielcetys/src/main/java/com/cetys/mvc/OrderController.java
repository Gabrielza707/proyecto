package com.cetys.mvc;

import org.springframework.stereotype.Controller;

@Controller
public class OrderController {
    final OrderRepository orderRepository;

    public OrderController(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;

        orderRepository.save(new Order("Engineer"));
        orderRepository.save(new Order("Administration"));
        orderRepository.save(new Order("Sales"));
    }

    //Todo: Crud Controller
}
