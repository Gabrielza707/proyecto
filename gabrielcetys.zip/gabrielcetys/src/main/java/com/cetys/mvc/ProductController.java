package com.cetys.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {
    final ProductRepository productRepository;
    final OrderRepository orderRepository;

    public ProductController(
            ProductRepository productRepository,
            OrderRepository orderRepository
    ) {
        this.productRepository = productRepository;
        this.orderRepository = orderRepository;

        productRepository.save(new Product("PS3", "Sony", 1));
        productRepository.save(new Product("iPhone xs", "Apple", 2));
        productRepository.save(new Product("Inspiron 1550", "Dell", 1));
    }

    @GetMapping("/")
    String listUsers(
            @RequestParam(name = "brand", defaultValue = "") String brand,
            @RequestParam(name = "quantity", defaultValue = "0") int quantity,
            Model model
    ){

        if (!brand.isEmpty() && quantity > 0){
            model.addAttribute("products", productRepository.findByBrandContainingAndQuantityGreaterThanEqual(brand, quantity));
        } else if (quantity > 0) {
            model.addAttribute("products", productRepository.findByQuantityGreaterThanEqual(quantity));
        } else if (!brand.isEmpty()){
            model.addAttribute("products", productRepository.findByBrandContainingOrderByNameDesc(brand));
        } else {
            model.addAttribute("products", productRepository.findAll());

        }
//        model.addAttribute("users", userRepository.findAll());
        return "product-list";
    }

    @GetMapping("/register")
    String registration(Product product, Model model){
        model.addAttribute("product", product);
        return "product-add";
    }

    @PostMapping("/add")
    ModelAndView addProduct(
            Product product,
            ModelMap model
    ) {
        productRepository.save(product);
        model.addAttribute("products", productRepository.findAll());
        return new ModelAndView("redirect:/");
    }

    @GetMapping("/edit/{id}")
    String editProduct(
            @PathVariable("id") int id,
            Model model
    ) {
        var product = productRepository.findById(id).get();
        model.addAttribute("product", product);
        var orders = orderRepository.findAll();
        model.addAttribute("orders", orders);

        return "product-edit";
    }

    @PostMapping("/update/{id}")
    ModelAndView updateProduct(
            @PathVariable("id") int id,
            Product editedProduct,
            Model model
    ) {
        productRepository.save(editedProduct);
        model.addAttribute("users", productRepository.findAll());
        return new ModelAndView("redirect:/");
    }

    @GetMapping("/delete/{id}")
    ModelAndView deleteProduct(
            @PathVariable("id") int id,
            Model model
    ) {

        productRepository.deleteById(id);
        model.addAttribute("users", productRepository.findAll());
        return new ModelAndView("redirect:/");
    }
}
