package com.cetys.mvc;

import javax.persistence.*;


@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Integer id;
    String name;
    String brand;
    Integer quantity;
    // Muchos productos a una orden
    @ManyToOne
    Order order;

    public Product() {

    }

    public Product(String name, String brand, Integer quantity) {
        this.name = name;
        this.brand = brand;
        this.quantity = quantity;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Order getOrder() {
        if(order == null){
            order = new Order();
        }
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }
}
