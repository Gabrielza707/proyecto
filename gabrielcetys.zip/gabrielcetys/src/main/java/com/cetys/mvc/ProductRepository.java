package com.cetys.mvc;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ProductRepository extends CrudRepository<Product, Integer> {
        // find limiter By Attribute Logic - OrderBy Attribute Order

        // find - By Email - OrdenBy Name Desc
        // email == s // email.compareTo(s)
    List<Product> findByBrandOrderByNameDesc(String s);

        // find By Email Containing OrderBy Name Desc
    List<Product> findByBrandContainingOrderByNameDesc(String s);

        // find - By Age GreaterThanEquak  - -
    List<Product> findByQuantityGreaterThanEqual(int i);
        // find - By [Email Containing] And [Age GreaterThanEqual]
    List<Product> findByBrandContainingAndQuantityGreaterThanEqual(String s, int i);


}
